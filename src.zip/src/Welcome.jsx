import React, {Component} from "react";
import logo from './images/logo.png'
import './css/Welcome.css'

class Welcome extends Component{
    render(){
        return(
            <div>
                <div className="welcome-text">
                <p>Welcome to <br/><span>ADDMS</span></p>
                </div>
                <div className="logo2">
                    <img src={logo} alt='ADDMS Logo'/>
                </div>
                <div className="welcome-btn">
                    <button >Continue</button>
                </div>

            </div>
        )
    }
}

export default Welcome