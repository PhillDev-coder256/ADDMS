import { initializeApp } from "firebase/app";
import {getAuth, GoogleAuthProvider, signInWithPopup} from 'firebase/auth';

const firebaseConfig = {
  apiKey: "AIzaSyDEj1laUr6IgY0zovKVDAne2e4t3o77Yi4",
  authDomain: "addms-new.firebaseapp.com",
  projectId: "addms-new",
  storageBucket: "addms-new.appspot.com",
  messagingSenderId: "197583971945",
  appId: "1:197583971945:web:336790138d2df6dbd5e4f8"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);

const provider = new  GoogleAuthProvider()

export const signInWithGoogle = () => {
  signInWithPopup(auth, provider).then((result) => {
    const name = result.user.displayName
    const email = result.user.email
    const profilePic = result.user.photoURL

    localStorage.setItem('name', name)
    localStorage.setItem('email', email)
    localStorage.setItem('profile', profilePic)
    
  }).catch((error) => {
    console.log('error');
  });
}