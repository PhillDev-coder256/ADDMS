import React, {Component} from 'react';
import logo from './images/logo.png'
// import './bootstrap/css/bootstrap.min.css'
import './css/Start.css'
import Welcome from './Welcome';
import { signInWithGoogle } from './firebase';
import {Link} from 'react-router-dom';

class Start extends Component{
	

	render(){

		return(
			
			<div>
				<div>
				{/* <Link to="/Welcome">Go to next page</Link> */}
				</div>
				<span className='left-span'></span>
				<span className='right-span'></span>
				<div className='logo1'>
					<img src={logo} alt='Kabale University Logo'/>
				</div>
				<div className='start-text'>
					<p>The digital <br/> way to go...!</p>
				</div>
				<div className='start-btn'>
					<button className='start' type='submit'>Get Started</button>
				</div>
				<div className='btn12'>
				<button onClick={signInWithGoogle} type="button" class="login-with-google-btn" >
				Sign in with Google
				</button>
				</div>
				
			</div>

			

		)
		


		
	}
}

export default Start