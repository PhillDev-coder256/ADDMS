import React, {Components} from 'react'

class Account extends Component{
    render(){
        return(
            <div>
                
            </div>
        )
    }
}