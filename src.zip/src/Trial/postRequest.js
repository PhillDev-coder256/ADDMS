import  React, {Component} from 'react'
import ReactDom from 'react-dom'
// import Router from 'react-router-dom'

class PostRequest extends Component{
    render(){
        return(
            <div>
                <button>Send</button>
            </div>
        )
       }
    }


export default PostRequest