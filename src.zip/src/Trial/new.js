import React, {Component} from 'react'

class New extends Component{
    render(){
        return(
            <div>
                New Component
            </div>
        )
    }
}