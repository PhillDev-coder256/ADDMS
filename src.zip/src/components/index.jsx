import React, {Component} from 'react'
import Header from './Header'
import Content from './Content'
import Navbar from './Nav'

class Home extends Component{
    render(){
        return(
            <div>
                <Header />
                <Content />
                <Navbar />
            </div>
        )
    }
} export default Home