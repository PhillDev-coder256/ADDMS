import React, {Component} from 'react'
import Profile from './images/profile.png'
import Logo from './images/logo.png'
import './css/Header.css'

class Header extends Component{

    getDateNow(){
        // let date = document.getElementById('date')
        let newDate = new Date();
        let year = newDate.getFullYear();
        let month = newDate.getMonth();
        let todaysDate = newDate.getDate();

        // let hours = newDate.getHours();
        // let minutes = newDate().getMinutes(); 
        // let seconds = newDate.getSeconds();

        // date.innerHTML = ' ' + todaysDate + '/' + month + '/' + year;
        return(
            <div className='dateNow' >
                <p>{todaysDate} / {month + 1} / {year}</p>
            </div>
        )
    }

    render(){
        return(
            <div className='header'>
                <div className='profile-pic'>
                    <img src={Profile} />
                </div>
                <div className='faculty'>
                    <p>Faculty of Computing, Library and Information Science</p>
                </div>
                <div className='p-name'>
                    <p>PhilDev-coder - 2021akit1778gf@kab.ac.ug</p>
                </div>
                <div className='date'>
                    {this.getDateNow()}
                </div>

                <div className='logo-1'>
                    <img src={Logo} />
                </div>
                
            </div>
        )
    }
}

export default Header