import React, {Component} from 'react'

class Acknowledgement extends Component{
    saveButton(){
        return(
            <div className='save-btn'>
                        <button className='save' type='submit'>
                            Save and Continue
                        </button>
                    </div>
        )
    }

    acknowledgement(){
        return(
            <div className='section'>
                            <h4>Acknowledgement page</h4>
                            <textarea placeholder="Those who contributed in any form to the completion of the Intern Exercise, Table of Contents, List of Acronynms, Abbreviations, Figures, and Tables">
                            </textarea>
                        </div>
        )
    }
    render(){
        
        return(
            <div>
                {this.acknowledgement()}
            </div>
        )
    }
}

export default Acknowledgement