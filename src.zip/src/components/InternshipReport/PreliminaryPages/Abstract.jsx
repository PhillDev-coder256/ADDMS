import React, {Component} from 'react'

class Abstract extends Component{
    saveButton(){
        return(
            <div className='save-btn'>
                        <button className='save' type='submit'>
                            Save and Continue
                        </button>
                    </div>
        )
    }

    abstract(){
        return(
            <div className='section'>
                            <h4>Abstract page</h4>
                            <textarea placeholder="This highlights key issues of the intern field objectives, experiences, challenges, recommendations, and conclusions">
                            </textarea>
                        </div>
        )
    }
    render(){
        
        return(
            <div>
                {this.abstract()}
            </div>
        )
    }
}

export default Abstract