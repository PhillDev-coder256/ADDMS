import React, {Component} from 'react'

class Approval extends Component{
    saveButton(){
        return(
            <div className='save-btn'>
                        <button className='save' type='submit'>
                            Save and Continue
                        </button>
                    </div>
        )
    }

    approval(){
        return(
            <div className='section'>
                            <h4>Approval page</h4>
                            <textarea placeholder="The Internee should confirm that the Internship/ IT training was conducted under the supervision of the Agency/ University supervisor as evidenced respectively and it is now ready for submission to the Faculty of Computing, Library, and Information Sciences at Kabale University">
                            </textarea>
                        </div>
        )
    }
    render(){
        
        return(
            <div>
                {this.approval()}
            </div>
        )
    }
}

export default Approval