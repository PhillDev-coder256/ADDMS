import React, {Component} from 'react'

class DeclarationPage extends Component{
    saveButton(){
        return(
            <div className='save-btn'>
                        <button className='save' type='submit'>
                            Save and Continue
                        </button>
                    </div>
        )
    }

    declarationPage(){
        return(
            <div className='section'>
                            <h4>Declaration page</h4>
                            <textarea placeholder="The Internee should confirm the originality and authenticity of the report and also acknowledge any form pf citations, quotations, and references to the third party's work/input as appropriate ">
                            </textarea>
                        </div>
        )
    }
    render(){
        
        return(
            <div>
                {this.declarationPage()}
            </div>
        )
    }
}

export default DeclarationPage