import React, {Component} from 'react'

class Appendices extends Component{
    saveButton(){
        return(
            <div className='save-btn'>
                        <button className='save' type='submit'>
                            Save and Continue
                        </button>
                    </div>
        )
    }

    getAppendices(){
        return(
            <div className='section'>
                <textarea placeholder='Any relevant information including Introductory and Acceptance letters'>

                </textarea>
            </div>
        )
    }
    render(){
        return(
            <div>
                {this.getAppendices()}
                {this.saveButton()}
            </div>
        )
    }
}

export default Appendices 