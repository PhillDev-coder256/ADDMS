import React, {Component} from 'react'

class References extends Component{
    saveButton(){
        return(
            <div className='save-btn'>
                        <button className='save' type='submit'>
                            Save and Continue
                        </button>
                    </div>
        )
    }

    getReferences(){
        return(
            <div className='section'>
                <textarea placeholder='All cited sources should be indicated per the academically accepted format(APA, IEEE, and HAVARD) '>

                </textarea>
            </div>
        )
    }
    render(){
        return(
            <div>
                {this.getReferences()}
                {this.saveButton()}
            </div>
        )
    }
}

export default References 