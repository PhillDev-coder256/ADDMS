import React, {Component} from 'react'

class ConfirmSubmit extends Component{
    render(){
        return(
            <div>
                 <div className='continue'>
                <p>By clicking submit, you agree that the information filled in this form will be sent to your University Supervisor and the Agency Supervisor</p>
                    <input type='submit' />
                    
                </div>  
            </div>
        )
    }
}

export default ConfirmSubmit