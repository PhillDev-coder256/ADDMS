import React, {Component} from 'react'
import Appendices from './Appendices'
import AgencyBackground from './ChapterOne/AgencyBackground'
import CoreFunctions from './ChapterOne/CoreFunctions'
import FundsSource from './ChapterOne/FundsSource'
import HostBackground from './ChapterOne/HostBackground'
import Introduction from './ChapterOne/Introduction'
import Objectives from './ChapterOne/Objectives'
import Structure from './ChapterOne/Structure'
import InternChallenges from './ChapterThree/Challenges'
import Conclusions from './ChapterThree/Conclusions'
import Recommendations from './ChapterThree/Recommendations'
import Accomplishments from './ChapterTwo/Accomplishments'
import Correlation from './ChapterTwo/Correlation'
import Departments from './ChapterTwo/Departments'
import Duties from './ChapterTwo/Duties'
import Position from './ChapterTwo/Position'
import Skills from './ChapterTwo/Skills'
import WorkSchedules from './ChapterTwo/WorkSchedules'
import References from './References'

class BodyReport extends Component{
    render(){
        return(
            <div>
                <div className='chapter1'>
                <Introduction />
                <AgencyBackground />
                <Objectives />
                <HostBackground />
                <Structure />
                <CoreFunctions />
                <FundsSource />
                </div>
                
                <p>You have completed Chapter One</p>

                <div className='chapter2'>
                    <h3>Chapter Two</h3>
                <Position />
                <Duties />
                <WorkSchedules />
                <Departments />
                <Accomplishments />
                <Skills />
                <Correlation />
                </div>

                <p>You have completed Chapter Two</p>

                <div className='chapter3'>
                    <h3>Chapter Three</h3>
                    <InternChallenges />
                    <Recommendations />
                    <Conclusions />
                </div>

                <p>You have completed Chapter Three</p>

                <div className='references'>
                    <h3>References</h3>
                    <References />

                </div>
                <div className='appendices'>
                    <h3>Appendices</h3>
                    <Appendices />
                    
                    
                </div>
            </div>
        )
    }
}

export default BodyReport