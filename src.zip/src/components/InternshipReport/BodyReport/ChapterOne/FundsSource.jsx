import React, {Component} from 'react'
import './introduction.css'

class FundsSource extends Component{
    saveButton(){
        return(
            <div className='save-btn'>
                        <button className='save' type='submit'>
                            Save and Continue
                        </button>
                    </div>
        )
    }

    fundsSource(){
        return(
            <div className='section'>
                            <h4>Source of funds for the Organization page</h4>
                            <textarea placeholder="Briefly explain the source of funds for the organization">
                            </textarea>
                        </div>
        )
    }
    render(){
        
        return(
            <div>
                {this.fundsSource()}
                {this.saveButton()}
            </div>
        )
    }
}

export default FundsSource