import React, {Component} from 'react'
import './introduction.css'

class HostBackground extends Component{
    saveButton(){
        return(
            <div className='save-btn'>
                        <button className='save' type='submit'>
                            Save and Continue
                        </button>
                    </div>
        )
    }

    hostBackground(){
        return(
            <div className='section'>
                            <h4>Host Organization Background</h4>
                            <textarea placeholder="Briefly explain the host organization background">
                            </textarea>
                        </div>
        )
    }
    render(){
        
        return(
            <div>
                {this.hostBackground()}
                {this.saveButton()}
            </div>
        )
    }
}

export default HostBackground