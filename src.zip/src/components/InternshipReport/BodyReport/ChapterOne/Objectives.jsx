import React, {Component} from 'react'
import './introduction.css'

class Objectives extends Component{
    saveButton(){
        return(
            <div className='save-btn'>
                        <button className='save' type='submit'>
                            Save and Continue
                        </button>
                    </div>
        )
    }

    objectives(){
        return(
            <div className='section'>
                            <h4>Objectives of the Organization page</h4>
                            <textarea placeholder="Briefly explain the objectives of the organization">
                            </textarea>
                        </div>
        )
    }
    render(){
        
        return(
            <div>
                {this.objectives()}
                {this.saveButton()}
            </div>
        )
    }
}

export default Objectives