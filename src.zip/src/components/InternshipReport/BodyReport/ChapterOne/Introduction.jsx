import React, {Component} from 'react'
import './introduction.css'

class Introduction extends Component{
    saveButton(){
        return(
            <div className='save-btn'>
                        <button className='save' type='submit'>
                            Save and Continue
                        </button>
                    </div>
        )
    }

    introduction(){
        return(
            <div className='section'>
                            <h4>Introduction page</h4>
                            <textarea placeholder="Give a brief description of your report">
                            </textarea>
                        </div>
        )
    }
    render(){
        
        return(
            <div>
                {this.introduction()}
                {this.saveButton()}
            </div>
        )
    }
}

export default Introduction