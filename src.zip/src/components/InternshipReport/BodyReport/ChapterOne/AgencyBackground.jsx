import React, {Component} from 'react'
import './introduction.css'

class AgencyBackground extends Component{
    saveButton(){
        return(
            <div className='save-btn'>
                        <button className='save' type='submit'>
                            Save and Continue
                        </button>
                    </div>
        )
    }

    agencyBackground(){
        return(
            <div className='section'>
                            <h4>Agency Background page</h4>
                            <textarea placeholder="Give a brief description of your report">
                            </textarea>
                        </div>
        )
    }
    render(){
        
        return(
            <div>
                {this.agencyBackground()}
                {this.saveButton()}
            </div>
        )
    }
}

export default AgencyBackground