import React, {Component} from 'react'
import './introduction.css'

class CoreFunctions extends Component{
    saveButton(){
        return(
            <div className='save-btn'>
                        <button className='save' type='submit'>
                            Save and Continue
                        </button>
                    </div>
        )
    }

    coreFunctions(){
        return(
            <div className='section'>
                            <h4>CoreFunctions of the Organization page</h4>
                            <textarea placeholder="Briefly explain the CoreFunctions of the organization">
                            </textarea>
                        </div>
        )
    }
    render(){
        
        return(
            <div>
                {this.coreFunctions()}
                {this.saveButton()}
            </div>
        )
    }
}

export default CoreFunctions