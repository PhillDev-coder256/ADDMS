import React, {Component} from 'react'
import './introduction.css'

class Structure extends Component{
    saveButton(){
        return(
            <div className='save-btn'>
                        <button className='save' type='submit'>
                            Save and Continue
                        </button>
                    </div>
        )
    }

    structure(){
        return(
            <div className='section'>
                            <h4>Structure of the Organization page</h4>
                            <textarea placeholder="Briefly explain the Structure of the organization">
                            </textarea>
                        </div>
        )
    }
    render(){
        
        return(
            <div>
                {this.structure()}
                {this.saveButton()}
            </div>
        )
    }
}

export default Structure