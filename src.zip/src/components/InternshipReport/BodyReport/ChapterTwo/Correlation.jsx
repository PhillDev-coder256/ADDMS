import React, {Component} from 'react'
import './introduction.css'

class Correlation extends Component{
    saveButton(){
        return(
            <div className='save-btn'>
                        <button className='save' type='submit'>
                            Save and Continue
                        </button>
                    </div>
        )
    }

    correlation(){
        return(
            <div className='section'>
                            <h4>Correlation with the University taught courses</h4>
                            <textarea placeholder="">
                            </textarea>
                        </div>
        )
    }
    render(){
        
        return(
            <div>
                {this.correlation()}
                {this.saveButton()}
            </div>
        )
    }
}

export default Correlation