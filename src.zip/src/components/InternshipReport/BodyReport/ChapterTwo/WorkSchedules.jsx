import React, {Component} from 'react'
import './introduction.css'

class WorkSchedules extends Component{
    saveButton(){
        return(
            <div className='save-btn'>
                        <button className='save' type='submit'>
                            Save and Continue
                        </button>
                    </div>
        )
    }

    workSchedules(){
        return(
            <div className='section'>
                            <h4>Work Schedules</h4>
                            <textarea placeholder="">
                            </textarea>
                        </div>
        )
    }
    render(){
        
        return(
            <div>
                {this.workSchedules()}
                {this.saveButton()}
            </div>
        )
    }
}

export default WorkSchedules