import React, {Component} from 'react'
import './introduction.css'

class Duties extends Component{
    saveButton(){
        return(
            <div className='save-btn'>
                        <button className='save' type='submit'>
                            Save and Continue
                        </button>
                    </div>
        )
    }

    duties(){
        return(
            <div className='section'>
                            <h4>Duties and roles performed</h4>
                            <textarea placeholder="">
                            </textarea>
                        </div>
        )
    }
    render(){
        
        return(
            <div>
                {this.duties()}
                {this.saveButton()}
            </div>
        )
    }
}

export default Duties