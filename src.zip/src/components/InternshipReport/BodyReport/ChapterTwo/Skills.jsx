import React, {Component} from 'react'
import './introduction.css'

class Skills extends Component{
    saveButton(){
        return(
            <div className='save-btn'>
                        <button className='save' type='submit'>
                            Save and Continue
                        </button>
                    </div>
        )
    }

    getskills(){
        return(
            <div className='section'>
                            <h4>New skills and knowledge learnt</h4>
                            <textarea placeholder="">
                            </textarea>
                        </div>
        )
    }
    render(){
        
        return(
            <div>
                {this.getskills()}
                {this.saveButton()}
            </div>
        )
    }
}

export default Skills