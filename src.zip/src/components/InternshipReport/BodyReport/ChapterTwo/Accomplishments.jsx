import React, {Component} from 'react'
import './introduction.css'

class Accomplishments extends Component{
    saveButton(){
        return(
            <div className='save-btn'>
                        <button className='save' type='submit'>
                            Save and Continue
                        </button>
                    </div>
        )
    }

    accomplishments(){
        return(
            <div className='section'>
                            <h4>Level of accomplishments of assigned duties and roles</h4>
                            <textarea placeholder="">
                            </textarea>
                        </div>
        )
    }
    render(){
        
        return(
            <div>
                {this.accomplishments()}
                {this.saveButton()}
            </div>
        )
    }
}

export default Accomplishments