import React, {Component} from 'react'
import './introduction.css'

class Position extends Component{
    saveButton(){
        return(
            <div className='save-btn'>
                        <button className='save' type='submit'>
                            Save and Continue
                        </button>
                    </div>
        )
    }

    getposition(){
        return(
            <div className='section'>
                            <h4>Position held in the organization</h4>
                            <textarea placeholder="">
                            </textarea>
                        </div>
        )
    }
    render(){
        
        return(
            <div>
                {this.getposition()}
                {this.saveButton()}
            </div>
        )
    }
}

export default Position