import React, {Component} from 'react'
import './introduction.css'

class Departments extends Component{
    saveButton(){
        return(
            <div className='save-btn'>
                        <button className='save' type='submit'>
                            Save and Continue
                        </button>
                    </div>
        )
    }

    getdepartment(){
        return(
            <div className='section'>
                            <h4>Work teams/departments</h4>
                            <textarea placeholder="">
                            </textarea>
                        </div>
        )
    }
    render(){
        
        return(
            <div>
                {this.getdepartment()}
                {this.saveButton()}
            </div>
        )
    }
}

export default Departments