import React, {Component} from 'react'
import './introduction.css'

class Conclusions extends Component{
    saveButton(){
        return(
            <div className='save-btn'>
                        <button className='save' type='submit'>
                            Save and Continue
                        </button>
                    </div>
        )
    }

    conclusions(){
        return(
            <div className='section'>
                            <h4>Conclusions</h4>
                            <textarea placeholder="">
                            </textarea>
                        </div>
        )
    }
    render(){
        
        return(
            <div>
                {this.conclusions()}
                {this.saveButton()}
            </div>
        )
    }
}

export default Conclusions