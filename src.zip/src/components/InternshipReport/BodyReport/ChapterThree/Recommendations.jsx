import React, {Component} from 'react'
import './introduction.css'

class Recommendations extends Component{
    saveButton(){
        return(
            <div className='save-btn'>
                        <button className='save' type='submit'>
                            Save and Continue
                        </button>
                    </div>
        )
    }

    recommendations(){
        return(
            <div className='section'>
                            <h4>Recommendations</h4>
                            <textarea placeholder="">
                            </textarea>
                        </div>
        )
    }
    render(){
        
        return(
            <div>
                {this.recommendations()}
                {this.saveButton()}
            </div>
        )
    }
}

export default Recommendations