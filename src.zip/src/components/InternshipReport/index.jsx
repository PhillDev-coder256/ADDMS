import React, {Component} from 'react'
import Header from '../Header'
import Navbar from '../Nav'
import BodyReport from './BodyReport'
import Report from './Report'

class InternshipReport extends Component{
    render(){
        return(
            <div>
                <Header />
                {/* <Report /> */}
                <BodyReport />
                <Navbar />
            </div>
        )
    }
}

export default InternshipReport