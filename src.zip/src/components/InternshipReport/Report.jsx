import React, {Component} from 'react'
import Logo from '../images/logo.png'
import './Report.css'
import DeclarationPage from './PreliminaryPages/declarationPage';
import Approval from './PreliminaryPages/Approval';
import Acknowledgement from './PreliminaryPages/Acknowledgement';
import Abstract from './PreliminaryPages/Abstract';

class Report extends Component{
    getAgencyName(){
        return(
            <div className='agencyName'>
                <input type='text' placeholder='Name of Agency' id='a-name' />
            </div>
        )
    }
    getDates(){
        return(
            <div className='Dates'>
                From 
                <input type='date' placeholder='Start date' />
                To
                <input type='date' placeholder='End date' />
            </div>
        )
    }
    getInternName(){
        return(
            <div className='internName'>
              <input type='text' placeholder='Name of internee' />  
            </div>
        )
    }
    getRegNumber(){
        return(
            <div className='reg'>
                <input type='text' placeholder='Registration Number' />
            </div>
        )
    }
    getProgramme(){
        return(
            <div className='programme'>
                <input type='text' placeholder='Programme offered' />
            </div>
        )
    }
    getDateNow(){
        let newDate = new Date();
        let year = newDate.getFullYear();
        let month = newDate.getMonth();
        let todaysDate = newDate.getDate();
        return(
            <div className='dateNow' >
                <p>{todaysDate} / {month + 1} / {year}</p>
            </div>
        )
    }

    saveButton(){
        return(
            <div className='save-btn'>
                        <button className='save' type='submit'>
                            Save and Continue
                        </button>
                    </div>
        )
    }

    render(){
        return(
            <div className='cover'>
                <div className='info-text' >
                    <p>** Every Internee is hereby required to fill in this form for his/ her report at the end of the exercise and this report should be cross checked and endorsed by both the field and University supervisors respectively. The report should be filled in English language as per the fields below **</p>
                </div>
                <form>
                    <div className='cover-page'>
                        <div className='header1'>
                            <div className='left'>
                                <h1>KABALE</h1>
                                <p>P.O.Box 317</p>
                                <p>Kabale - Uganda</p>
                                <p>Email:<a href='info@kab.ac.ug'>info@kab.ac.ug</a></p>
                                <p><a href='admissions@kab.ac.ug'>admissions@kab.ac.ug</a></p>

                            </div>
                            <div className='logo'>
                                <img src={Logo} />
                            </div>
                            <div className='right'>
                            <h1>UNIVERSITY</h1>
                                <p>Tel: <a href='tel:256392848355' >256-392-848355</a>/<a href='tel:04864-26463' >04864-26463</a></p>
                                <p>Mob: <a href='tel:256782860259'>256-7828-60259</a></p>
                                <p>Fax: <a href='tel:256486422803'>256-4864-22803</a></p>
                                <p>Website: <a href='www.kab.ac.ug'>www.kab.ac.ug</a></p>
                                
                            </div>
                        </div>
                        <div className='faculty'>
                        <select>
                            <option>Choose faculty</option>
                            <option>Faculty of Computing, Library and Information Sciences</option>
                            <option>Faculty of Agriculture</option>
                            <option>Faculty of Agribusiness</option>
                            <option>Faculty of Medicine</option>
                            <option>Faculty of Social Work</option>
                            <div></div>
                        </select>
                    </div>
                    <p>A REPORT ON INTERNSHIP/IT CONDUCTED AT</p>
                    {this.getAgencyName()}
                    {this.getDates()}
                    <p>By</p>
                    {this.getInternName()}
                    {this.getRegNumber()}
                    
                    <div className='info'>
                        <p>Internship/IT report submitted to the faculty of Computing, Library and Information Sciences in partial fulfillment of the requirements for award of </p>
                        {this.getProgramme()}
                        <p>of Kabale University</p>
                    </div>

                    {this.getDateNow()}
                    </div>

                    {this.saveButton()}
                    <div className='preliminary-pages'>
                    <p>Preliminary Pages</p>
                          <DeclarationPage />
                          <Approval />
                          <Acknowledgement />
                          <Abstract />
                    </div>
                </form>
            </div>
        )
    }
}

export default Report