import React, {Component} from 'react'
import './css/Nav.css'

class Navbar extends Component{
    render(){
        return(
        //    <div>
        //        <div className='navbar'>
        //         <a href=''>Home</a>
        //         <a href=''>Search</a>
        //         <a href=''>Notifications</a>
        //         <a href=''>Inbox</a>
        //         <a href=''>Profile</a>
        //        </div>
        //    </div>
            <div>
             <div class="nav-bar">

                <div class="nav-bar-links">
                    <ul>
                        <div class="menu">
                            
                        <li >
                            <span></span>
                            <a href="">Home</a></li>
                        <li ><a href="">Search</a></li>
                        <li ><a href="">Notifications</a></li>
                        <li ><a href="">Inbox</a></li> 
                        <li ><a href="">Profile</a></li>             
                        </div>
                    </ul>
                </div>

            </div>
   
            </div>
        )
    }
}

export default Navbar