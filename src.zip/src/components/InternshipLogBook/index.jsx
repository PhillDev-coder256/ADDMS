import React, {Component} from 'react'
import Header from '../Header'
import Navbar from '../Nav'
import Activities from './Activities'
import Orientation from './Orientation'

class LogBook extends Component{
    render(){
        return(
            <div>
                <Header />
                <Orientation />
                <Activities />
                <Navbar />
            </div>
        )
    }
}

export default LogBook