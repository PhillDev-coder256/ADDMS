<?php
if(isset($_POST['submit_btn']){
    echo 'I echo out PHP';
}

?>