import React, {Component} from 'react'

class Orientation extends Component{
    render(){
        return (
            <div>
                
                <h3>Orientation for students</h3>
                <p>Soon you are beginning Internship/Industrial training. It is important for you to understand the importance of this practical course, which, indeed, prepares you to face realities of your respective professions once you have completed your studies. </p>
                <p>The Internship/ Industrial training Exercise is an important stage in the process of your training. It is a synthesis of theoretical knowledge learnt during a certain period, and it enables you to translate knowledge and know-how into competences.</p>
                <p>Internship/ Industrial training as an academic activity, programmed during the acdemic year according to the period provided for this activity in the academic calendar.</p>
                <p>Thus , before the period of internship?Industrial training, the student concerned must identify theenerprise ? Agency or Institution in which he / she wishes to carry out the internship industrial training exercise, the ground supervisor who must meet some conditions such as the area of expertise and the Academic qualifications. All this information is presented to the Department to have agreement</p>
                <p>In provision of this information, the Faculty will provide you with this electronic log book duly filled with the information required.</p>
                <p>This approach will enable you to benefit from all the period reserved for the internship/ industrial training.</p>
                <p>The internship/ industrial training log book must be filled in daily by writing in the main activities and observations. It is regularly submitted to the Agency supervisor who issues his/her observations, appreciations, remarks and comments on the progress of the Internship industrial training activities.</p>
                <p>The internship / industrial training log book is also requested by the supervisor selected by the industrial training committee when he/she is on field supervision. Like the ground supervisor, he/she puts in his /her observations, appreciations, remarks, and comments on the progress of internship/industrial training.</p>
                <p>At the end of the internship exercise, the student makes a report that he/she must submit to the Department together with the log book. A report without a log book has no academic value, and it can in no way be accepted by the Faculty/Department. </p>
                <p>The lecturer who will be selected to assess the internship report will consider the cohension between the logbook and the report. The log book contains a report format which should be referred to in the process of report writing.</p>
                <p>Therefore, dear students, we wish you a pleasant  and beneficial period of internship/industrial training. We are convinced that it will give you a new and necessary experience for your future career.</p>

                <h5>Faculty Dean-FoCLIS</h5>
                <br></br>
            </div>
        )
    }
}

export default Orientation