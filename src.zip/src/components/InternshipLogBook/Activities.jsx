import React, {Component} from 'react'
import './css/activities.css'

class Activities extends Component{
    render(){
        return(
            <div>
                <form>
                <div className='activities' >
                    
                    <label htmlFor='activities' >Daily Activities</label><br/>
                    <textarea id='activities' placeholder='Internship activities'>

                    </textarea>
                </div>
                <div className='lessons' >
                    <label htmlFor='lessons' >Lessons learnt</label><br/>
                    <textarea id='lessons' placeholder='Lessons leanrt during Internship'>

                    </textarea>
                </div>
                <div className='challenges' >
                    <label htmlFor='challenges' >Challenges faced</label><br/>
                    <textarea id='challenges' placeholder='Internship challenges'>

                    </textarea>
                </div>
                <div className='recommendations' >
                    <label htmlFor='recommendations' >Recommendations</label><br/>
                    <textarea id='recommendations' placeholder='Recommendations'>

                    </textarea>
                </div>
                <div className='continue'>
                <p>By clicking submit, you agree that the information filled in this form will be sent to your University Supervisor and the Agency Supervisor</p>
                    <input type='submit' />
                    
                </div>
                </form>

            </div>
        )
    }
}
export default Activities