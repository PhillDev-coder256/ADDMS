import React, {Component} from 'react'
import './css/Content.css'
import image1 from './images/2.jpg'
import image2 from './images/3.jpg'
import image3 from './images/4.jpg'
// import image4 from './images/2.jpg'

class Content extends Component{
    render(){
        return(
            <div>
                <div className='components'>
                    <div className='span'>
                        <div className='pic1'>
                            <img src={image1} alt='Image' />
                        </div>
                        <div className='caption'>
                            <p>Internship Logbook</p>
                        </div>
                        <div className='hr'>
                            <hr></hr>
                        </div>
                    </div>

                    <div className='span'>
                        <div className='pic2'>
                            <img src={image2} alt='Image' />
                        </div>
                        <div className='caption'>
                            <p>Research Proposals</p>
                        </div>
                        <div className='hr'>
                            <hr></hr>
                        </div>
                    </div>

                    <div className='span'>
                        <div className='pic3'>
                            <img src={image2} alt='Image' />
                        </div>
                        <div className='caption'>
                            <p>Final Year Projects</p>
                        </div>
                        <div className='hr'>
                            <hr></hr>
                        </div>
                    </div>

                    <div className='span'>
                        <div className='pic4'>
                            <img src={image2} alt='Image' />
                        </div>
                        <div className='caption'>
                            <p>Internship Report</p>
                        </div>
                        <div className='hr'>
                            <hr></hr>
                        </div>
                    </div>

                    <div className="sup-btn">
                    <button ><small>Login as  Supervisor</small></button>
                    </div>
                </div>
            </div>
        )
    }
}

export default Content