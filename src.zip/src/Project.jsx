import React, {Component} from 'react'
import './css/intern.css'
import images from './images/3.jpg'

class Project extends Component{
    render(){
        return(
            <div>
                <div className='image'>
                    <img src={images}/>
                </div>
                <div className='big-caption'>
                    <p>Go digital with your final year projects</p>
                </div>
                <div className='small-caption'>
                    <p>Digitalise the storage and access of final year projects and project proposals</p>
                </div>
                <div className='page-no'>
                    <span></span>
                </div>
                <div className='prev-btn'>
                    <button>Previous</button>
                </div>
                <div className='next-btn'>
                    <button>Next</button>
                </div>

            </div>
        )
    }
}

export default Project