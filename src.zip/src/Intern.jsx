import React, {Component} from 'react'
import './css/intern.css'
import images from './images/4.jpg'

class Intern extends Component{
    render(){
        return(
            <div>
                <div className='image'>
                    <img src={images}/>
                </div>
                <div className='big-caption'>
                    <p>Go digital about your Internship program</p>
                </div>
                <div className='small-caption'>
                    <p>Upload your daily Internship tasks online and engage with your supervisors online</p>
                </div>
                <div className='page-no'>
                    <span></span>
                </div>
                {/* <div className='prev-btn'>
                    <button>Previous</button>
                </div> */}
                <div className=' next-btn-1'>
                    <button>Next</button>
                </div>

            </div>
        )
    }
}

export default Intern