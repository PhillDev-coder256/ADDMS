import React, {Component} from 'react'
import './css/login.css'

class Login extends Component{
    getUsername(){
        return(
            <div className='agencyName'>
                <input type='text' placeholder='Username or email' id='a-name' />
            </div>
        )
    }

    getPassword(){
        return(
            <div className='pass'>
                <input type='password' placeholder='Password' />
            </div>
        )
    }

    loginButton(){
        return(
            <div className='login-btn'>
                        <button className='login' type='submit'>
                            Login
                        </button>
                    </div>
        )
    }
    
    createAccount(){
        return(
            <div className='login-btn'>
                        <button  className='login' type='submit'>
                            Create Account
                        </button>
                    </div>
        )
    }
    render(){
        return(
            <div className='wrapper'>
                {this.getUsername()}
                {this.getPassword()}
                {this.loginButton()}
                 <h3>Don't have an account ?</h3>
                {this.createAccount()}
            </div>
        )
    }
}

export default Login