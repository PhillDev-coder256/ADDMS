import React, {Component} from 'react';
import Start from './Start';
import Welcome from './Welcome';
import Intern from './Intern';
import Project from './Project';
import Research from './Research';
import Home from './components';
import LogBook from './components/InternshipLogBook';
import InternshipReport from './components/InternshipReport'
import Supervisor from './components/AgencySupervisor';
import PostRequest from './Trial/postRequest';
import Signup from './Enroll';
import Login from './Login';
import Header from './components/Header';
import Navbar from './components/Nav';
import Form from './Form';

class App extends Component{
	render(){

		return(
			<div>
				{/* <Header /> */}
				{/* <Signup /> */}
				<Start />
				{/* <Welcome /> */}
				{/* <Login /> */}
				{/* <Signup /> */}
				{/* <Intern /> */}
				{/* <Research /> */}
				{/* <Project /> */}
				{/* <Home /> */}
				{/* <LogBook /> */}
				{/* <Demo /> */}
				{/* <InternshipReport /> */}
				{/* <Supervisor /> */}
				{/* <PostRequest /> */}
				{/* <Navbar /> */}
				{/* <Form /> */}
			</div>
			
		)

	}
}

export default App