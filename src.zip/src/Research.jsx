import React, {Component} from 'react'
import './css/intern.css'
import images from './images/2.jpg'

class Research extends Component{
    render(){
        return(
            <div>
                <div className='image'>
                    <img src={images}/>
                </div>
                <div className='big-caption'>
                    <p>Go digital with your research proposals</p>
                </div>
                <div className='small-caption'>
                    <p>Upload, store, and access research proposals at any convinient time you wish</p>
                </div>
                <div className='page-no'>
                    <span></span>
                </div>
                <div className='prev-btn'>
                    <button>Previous</button>
                </div>
                <div className='next-btn'>
                    <button>Next</button>
                </div>

            </div>
        )
    }
}

export default Research