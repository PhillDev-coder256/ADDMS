import React, {Component} from 'react'
import './css/Signup.css'

class Enroll extends Component{
    academicYear(){
        return(
            <div className='academicYear'>
                <input type='text' placeholder='AcademicYear(e.g 2022/2023)' />
            </div>
        )
    }
    getName(){
        return(
            <div className='s_name'>
                <input type='text' placeholder='Name of student' />
            </div>
        )
    }
    getRegNo(){
        return(
            <div className='reg'>
                <input type='text' placeholder='Registration Number' />
            </div>
        )
    }
    getDept(){
        return(
            <div className='dept'>
               <select>
                   <option>Select department</option>
                   <option>Department of Information Technology</option>
                   <option>Depatment of Business Studies</option>
                   <option>Department of Technology</option>
               </select>
            </div>
        )
    }
    getA_name(){
        return(
            <div className='a_name'>
                <input type='text' placeholder='Name of organization / Agency' />
            </div>
        )
    }
    getA_supervisor(){
        return(
            <div className='a_supervisor' >
                <input type='text' placeholder='Agency Supervisor' />
            </div>
        )
    }
    getU_supervisor(){
        return(
            <div className='u_supervisor'>
                <input type='text' placeholder='University Supervisor' />
            </div>
        )
    }
    getemail(){
        return(
            <div className='email'>
                <input type='email' placeholder='University Email(e.g 2021akit1778gf@kab.ac.ug)' />
            </div>
        )
    }

    getPassword(){
        return(
            <div className='pass'>
                <input type='password' placeholder='Password' />
            </div>
        )
    }
    handleClick(){
        prompt('hello')
    }
    signupButton(){
        return(
            <div className='enroll-btn'>
                        <button onClick={this.handleClick} className='enroll' type='submit'>
                            Enroll
                        </button>
                    </div>
        )
    }
    render(){
        return(
            
            <div className='wrapper'>
                
                <h4>Enroll for the Internship programme by filling out this form </h4>
                {this.academicYear()}
                {this.getName()}
                {this.getRegNo()}
                {this.getDept()}
                {this.getA_name()}
                {this.getA_supervisor()}
                {this.getU_supervisor()}
                {/* {this.getPassword()} */}
                {this.signupButton()}
            </div>
        )
    }
}

export default Enroll